#include <Wire.h>
#include <RTClib.h>
#include <LiquidCrystal_I2C.h>
#include <WiFi.h>
#include <WebServer.h>

// ================== RTC + LCD ==================
RTC_DS3231 rtc;
LiquidCrystal_I2C lcd(0x27, 16, 2);   // LCD 16x2 addr 0x27

// ================== UART2 TỚI PIC ==================
#define RXD2 16     // RX2 (không bắt buộc dùng)
#define TXD2 17     // TX2 -> PIC RC7

// ================== NÚT BẤM ==================
#define BTN_DAY      32
#define BTN_NIGHT    33
#define BTN_PR_A     25
#define BTN_PR_B     26

// ================== WIFI STA ==================
const char* STA_SSID = "NV6.10";   // <<< ĐỔI SSID
const char* STA_PASS = "nv6.10@#";      // <<< ĐỔI PASSWORD

WebServer server(80);

// ================== BIẾN MODE ==================
String currentModeBase = "DAY";  // "DAY", "NIGHT", "PR_A", "PR_B"

// src: 0 = RTC, 1 = BUTTON, 2 = APP
uint8_t currentSrc = 0;

bool   manualMode      = false;   // false = AUTO (RTC), true = manual (BT/app)
int    lastButtonIndex = -1;      // 0..3 nếu mode do nút set, -1 nếu do APP/RTC

// dùng cho debounce nút
int lastBtnState[4] = {1,1,1,1};

// dùng cho LCD update
unsigned long lastLcdUpdate = 0;

// ================== HÀM PHỤ ==================

// Map chuỗi mode -> ký tự gửi xuống PIC
char modeIdCharFromString(const String &m) {
  if (m == "DAY")   return '1';
  if (m == "NIGHT") return '2';
  if (m == "PR_A")  return '3';
  if (m == "PR_B")  return '4';
  return '1';
}

// Gửi 2 byte xuống PIC: [mode_id][src_id]
void sendModeToPIC() {
  char modeId = modeIdCharFromString(currentModeBase);
  char srcId  = '0' + currentSrc;   // 0,1,2 -> '0','1','2'

  Serial2.write(modeId);   // byte 1: mode
  Serial2.write(srcId);    // byte 2: source

  Serial.print("[ESP32] SEND MODE -> PIC: ");
  Serial.print(currentModeBase);
  Serial.print(" (src=");
  if (currentSrc == 0) Serial.print("RTC");
  else if (currentSrc == 1) Serial.print("BT");
  else if (currentSrc == 2) Serial.print("APP");
  else Serial.print(currentSrc);
  Serial.println(")");
}

// Lấy mode tự động theo giờ RTC
String getModeFromTime(const DateTime &now) {
  int h = now.hour();
  if (h >= 22 || h < 5) return "NIGHT";  // 22h-5h
  return "DAY";                          // còn lại
}

// Cập nhật LCD: TIME + MODE + (RTC/BT/APP)
void updateLCD(const DateTime &now) {
  char buf[16];

  // Dòng 1: TIME:HH:MM:SS
  lcd.setCursor(0, 0);
  sprintf(buf, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  lcd.print("TIME:");
  lcd.print(buf);
  // xóa phần thừa nếu có
  int len = 5 + 8;
  for (int i = len; i < 16; i++) lcd.print(" ");

  // Dòng 2: MODE:XXXX RTC/BT/APP
  lcd.setCursor(0, 1);
  lcd.print("MODE:");
  lcd.print(currentModeBase);
  lcd.print(" ");

  if (currentSrc == 0)
    lcd.print("RTC");
  else if (currentSrc == 1)
    lcd.print("BT ");
  else if (currentSrc == 2)
    lcd.print("APP");
  else
    lcd.print("   ");

  // xóa phần còn lại
  int used = 5 + currentModeBase.length() + 1 + 3; // MODE: + mode + space + 3 chữ
  for (int i = used; i < 16; i++) lcd.print(" ");
}

// Set manual mode từ BUTTON
void setManualModeFromButton(const String &m, const DateTime &now, int btnIndex) {
  manualMode      = true;
  currentModeBase = m;
  currentSrc      = 1;      // BUTTON
  lastButtonIndex = btnIndex;

  Serial.print("[ESP32] Manual MODE by BUTTON = ");
  Serial.println(currentModeBase);

  sendModeToPIC();
}

// Set manual mode từ APP
void setManualModeFromApp(const String &m) {
  manualMode      = true;
  currentModeBase = m;
  currentSrc      = 2;      // APP
  lastButtonIndex = -1;     // không gắn với nút nào

  Serial.print("[ESP32] Manual MODE by APP = ");
  Serial.println(currentModeBase);

  sendModeToPIC();
}

// ================== HTTP HANDLERS ==================
// /mode?m=DAY|NIGHT|PR_A|PR_B
void handleMode() {
  if (!server.hasArg("m")) {
    server.send(400, "text/plain", "Missing param m");
    return;
  }

  String m = server.arg("m");
  if (m == "DAY" || m == "NIGHT" || m == "PR_A" || m == "PR_B") {
    setManualModeFromApp(m);    // lệnh từ app
    server.send(200, "text/plain", "OK");
  } else {
    server.send(400, "text/plain", "Invalid mode");
  }
}

// /status: cho debug/test
void handleStatus() {
  DateTime now = rtc.now();
  String s = "TIME:";
  s += String(now.hour()) + ":" + String(now.minute()) + ":" + String(now.second());
  s += " MODE:" + currentModeBase;
  if (currentSrc == 0) s += " RTC";
  else if (currentSrc == 1) s += " BT";
  else if (currentSrc == 2) s += " APP";
  server.send(200, "text/plain", s);
}

// root - test
void handleRoot() {
  String html = "<html><body><h3>ESP32 Traffic Test</h3>";
  html += "Current MODE: " + currentModeBase;
  if (currentSrc == 0) html += " (RTC)";
  else if (currentSrc == 1) html += " (BT)";
  else if (currentSrc == 2) html += " (APP)";
  html += "<br>Use /mode?m=DAY|NIGHT|PR_A|PR_B</body></html>";
  server.send(200, "text/html", html);
}

// ================== XỬ LÝ NÚT BẤM ==================
void handleButtons(const DateTime &now) {
  int pins[4]   = {BTN_DAY, BTN_NIGHT, BTN_PR_A, BTN_PR_B};
  String modes[4] = {"DAY", "NIGHT", "PR_A", "PR_B"};

  for (int i = 0; i < 4; i++) {
    int state = digitalRead(pins[i]);   // INPUT_PULLUP => nhấn = LOW
    if (state == LOW && lastBtnState[i] == HIGH) {
      // cạnh xuống = vừa nhấn
      delay(30); // chống dội
      if (digitalRead(pins[i]) == LOW) {
        Serial.print("[ESP32] Button index ");
        Serial.print(i);
        Serial.println(" pressed");

        // Nếu đang manual & nhấn lại cùng nút -> về AUTO (RTC)
        if (manualMode && lastButtonIndex == i && currentSrc == 1) {
          manualMode      = false;
          lastButtonIndex = -1;
          currentSrc      = 0;    // RTC
          Serial.println("[ESP32] Return to AUTO (RTC)");
          // cập nhật mode theo RTC hiện tại
          currentModeBase = getModeFromTime(now);
          sendModeToPIC();
        } else {
          // Sang manual bằng nút
          setManualModeFromButton(modes[i], now, i);
        }
      }
    }
    lastBtnState[i] = state;
  }
}

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);
  Serial.println();
  Serial.println("ESP32 Traffic Controller (RTC + LCD + Buttons + App HTTP)");

  // UART2 tới PIC
  Serial2.begin(9600, SERIAL_8N1, RXD2, TXD2);

  // I2C: RTC + LCD
  Wire.begin(21, 22);

  if (!rtc.begin()) {
    Serial.println("RTC NOT FOUND!");
    while (1) delay(1000);
  }
  if (rtc.lostPower()) {
    Serial.println("RTC lost power, set time from compile time");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("ESP32 TRAFFIC");
  lcd.setCursor(0,1);
  lcd.print("Init...");

  // Nút bấm
  pinMode(BTN_DAY,      INPUT_PULLUP);
  pinMode(BTN_NIGHT,    INPUT_PULLUP);
  pinMode(BTN_PR_A,     INPUT_PULLUP);
  pinMode(BTN_PR_B,     INPUT_PULLUP);

  // Khởi tạo biến nút
  lastBtnState[0] = digitalRead(BTN_DAY);
  lastBtnState[1] = digitalRead(BTN_NIGHT);
  lastBtnState[2] = digitalRead(BTN_PR_A);
  lastBtnState[3] = digitalRead(BTN_PR_B);

  // WiFi STA
  WiFi.mode(WIFI_STA);
  WiFi.begin(STA_SSID, STA_PASS);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("WiFi connected! IP = ");
  Serial.println(WiFi.localIP());

  // HTTP server
  server.on("/",        HTTP_GET, handleRoot);
  server.on("/mode",    HTTP_GET, handleMode);
  server.on("/status",  HTTP_GET, handleStatus);
  server.begin();
  Serial.println("HTTP server started on port 80");

  delay(1000);
  lcd.clear();
}

// ================== LOOP ==================
void loop() {
  // xử lý request từ app
  server.handleClient();

  // đọc thời gian hiện tại
  DateTime now = rtc.now();

  // nếu đang AUTO (RTC) thì mode phụ thuộc giờ
  if (!manualMode) {
    String autoMode = getModeFromTime(now);
    if (autoMode != currentModeBase || currentSrc != 0) {
      currentModeBase = autoMode;
      currentSrc      = 0;     // RTC
      Serial.print("[ESP32] AUTO RTC MODE = ");
      Serial.println(currentModeBase);
      sendModeToPIC();
    }
  }

  // xử lý nút bấm
  handleButtons(now);

  // cập nhật LCD mỗi 500ms
  unsigned long nowMs = millis();
  if (nowMs - lastLcdUpdate > 500) {
    lastLcdUpdate = nowMs;
    updateLCD(now);
  }

  delay(5);
}
