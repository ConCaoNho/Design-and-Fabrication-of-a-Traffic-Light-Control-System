#include <16F887.h>
#fuses HS, NOWDT, NOLVP, NOPROTECT
#use delay(clock=20000000)

// UART t? ESP32: RC7 = RX (nh?n), RC6 = TX (kh�ng c?n d�ng)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7, stream=ESP, ERRORS)

// ================= LED GIAO TH�NG =================
// D�y LED G?N PIC = HU?NG A
// D�y LED XA   PIC = HU?NG B
#define LED_A_GREEN    PIN_D0   // g?n PIC, d�n xanh A
#define LED_A_YELLOW   PIN_D1
#define LED_A_RED      PIN_D2
#define LED_A_LEFT     PIN_D3

#define LED_B_GREEN    PIN_D4   // xa PIC, d�n xanh B
#define LED_B_YELLOW   PIN_D5
#define LED_B_RED      PIN_D6
#define LED_B_LEFT     PIN_D7

// ================= 74HC595 CHO 7-SEG =================
// Module g?n PIC = hu?ng A, module xa = hu?ng B
#define SR_DATA   PIN_C0
#define SR_CLK    PIN_C1
#define SR_LATCH  PIN_C2

// B?ng m� 7-seg (common CATHODE), module ANODE CHUNG => ph?i d?o bit (~)
const int8 SEG_DIGIT[10] = {
   0b00111111, // 0
   0b00000110, // 1
   0b01011011, // 2
   0b01001111, // 3
   0b01100110, // 4
   0b01101101, // 5
   0b01111101, // 6
   0b00000111, // 7
   0b01111111, // 8
   0b01101111  // 9
};

// ================= MODE / STATE =================
// current_mode: 1 = DAY, 2 = NIGHT, 3 = PR_A, 4 = PR_B
int8 current_mode = 1;
int8 last_mode    = 0;

// th�m d? nh?n 2 byte t? ESP32
int8 current_src = 0;   // 0 = RTC, 1 = BT, 2 = APP
int8 uart_phase  = 0;   // 0 = ch? byte mode, 1 = ch? byte source

// Pha cho mode DAY:
// 0=A_GREEN, 1=A_YELLOW, 2=A_LEFT, 3=B_GREEN, 4=B_YELLOW, 5=B_LEFT
int8 phase_id = 0;
int8 phase_remaining_sec = 0;

// Th?i gian hi?n th? tr�n 2 c?m 7-seg
int8 remA = 0;   // b?ng g?n PIC (hu?ng A)
int8 remB = 0;   // b?ng xa  PIC (hu?ng B)

// tick th?i gian
int16 ms_accum = 0;
int16 blink_ms = 0;
int1  blink_on = 0;

// ================= 74HC595 / 7-SEG =================
void shift595_send_byte(int8 value) {
   int i;
   for(i=0;i<8;i++) {
      output_bit(SR_DATA, (value & 0x80) != 0);
      output_high(SR_CLK);
      delay_us(5);
      output_low(SR_CLK);
      delay_us(5);
      value <<= 1;
   }
}

void show_AB_count(int8 A_sec, int8 B_sec) {
   int8 A_tens = A_sec / 10;
   int8 A_ones = A_sec % 10;
   int8 B_tens = B_sec / 10;
   int8 B_ones = B_sec % 10;

   output_low(SR_LATCH);

   // Th? t? g?i: B_ones, B_tens, A_ones, A_tens
   shift595_send_byte(~SEG_DIGIT[B_ones]);
   shift595_send_byte(~SEG_DIGIT[B_tens]);
   shift595_send_byte(~SEG_DIGIT[A_ones]);
   shift595_send_byte(~SEG_DIGIT[A_tens]);

   output_high(SR_LATCH);
   delay_us(5);
   output_low(SR_LATCH);
}

// ================= LED HELPERS =================
void all_off() {
   output_d(0x00);
}

// �?t LED theo phase_id cho mode DAY, m?i hu?ng ch? 1 d�n
void set_leds_for_phase() {
   all_off();

   switch(phase_id) {
      case 0: // A xanh, B d?
         output_bit(LED_A_GREEN, 1);
         output_bit(LED_B_RED,   1);
         break;

      case 1: // A v�ng, B d?
         output_bit(LED_A_YELLOW, 1);
         output_bit(LED_B_RED,    1);
         break;

      case 2: // A r? tr�i, B d?
         output_bit(LED_A_LEFT, 1);
         output_bit(LED_B_RED,  1);
         break;

      case 3: // B xanh, A d?
         output_bit(LED_B_GREEN, 1);
         output_bit(LED_A_RED,   1);
         break;

      case 4: // B v�ng, A d?
         output_bit(LED_B_YELLOW, 1);
         output_bit(LED_A_RED,    1);
         break;

      case 5: // B r? tr�i, A d?
         output_bit(LED_B_LEFT, 1);
         output_bit(LED_A_RED,  1);
         break;
   }
}

int8 get_green_time() { return 20; }   // xanh 20s
int8 get_left_time()  { return 15; }   // r? tr�i 15s

// ================= UART NH?N 2 BYTE T? ESP32 =================
// ESP32 g?i: byte1: '1'..'4' = DAY/NIGHT/PR_A/PR_B
//            byte2: '0'..'2' = RTC/BT/APP
void handle_uart() {
   int8 c;
   if(kbhit(ESP)) {
      c = getc(ESP);

      if(uart_phase == 0) {
         // ch? byte mode
         if(c >= '1' && c <= '4') {
            current_mode = c - '0';  // '1'->1, '2'->2...
            uart_phase   = 1;        // ti?p theo ch? source
         }
         else {
            // n?u nh?n r�c, gi? nguy�n phase=0
         }
      } else {
         // ch? byte source
         if(c >= '0' && c <= '2') {
            current_src = c - '0';   // '0'->0, '1'->1...
         }
         // D� d�ng hay r�c, sau byte th? 2 cung quay v? ch? frame m?i
         uart_phase = 0;
      }
   }
}

// ================= T�NH remA / remB T? phase (mode DAY) =================
void compute_counts_from_phase() {
   int8 G = get_green_time();
   int8 L = get_left_time();
   int8 Y = 3;

   switch(phase_id) {
      case 0: // A GREEN, B RED
         remA = phase_remaining_sec;
         remB = phase_remaining_sec + Y + L;   // B ch? v�ng+tr�i
         break;
      case 1: // A YELLOW, B RED
         remA = phase_remaining_sec;
         remB = phase_remaining_sec + L;
         break;
      case 2: // A LEFT, B RED
         remA = phase_remaining_sec;
         remB = phase_remaining_sec;           // h?t tr�i l� t?i B
         break;
      case 3: // B GREEN, A RED
         remB = phase_remaining_sec;
         remA = phase_remaining_sec + Y + L;
         break;
      case 4: // B YELLOW, A RED
         remB = phase_remaining_sec;
         remA = phase_remaining_sec + L;
         break;
      case 5: // B LEFT, A RED
         remB = phase_remaining_sec;
         remA = phase_remaining_sec;
         break;
      default:
         remA = remB = 0;
         break;
   }
}

// ================= INIT MODE STATE =================
void init_mode_state() {
   ms_accum = 0;
   blink_ms = 0;
   blink_on = 0;
   remA = 0;
   remB = 0;

   if(current_mode == 1) {
      // DAY: b?t d?u t? pha A xanh
      phase_id = 0;
      phase_remaining_sec = get_green_time();
      compute_counts_from_phase();
      set_leds_for_phase();
      show_AB_count(remA, remB);
   }
   else if(current_mode == 2) {
      // NIGHT: 2 v�ng nh?p nh�y, 2 b?ng = 00
      all_off();
      output_bit(LED_A_YELLOW,1);
      output_bit(LED_B_YELLOW,1);
      remA = remB = 0;
      show_AB_count(remA, remB);
   }
   else if(current_mode == 3) {
      // PR_A: A xanh, B d?, 2 b?ng = 99
      all_off();
      output_bit(LED_A_GREEN,1);
      output_bit(LED_B_RED,  1);
      remA = 99;
      remB = 99;
      show_AB_count(remA, remB);
   }
   else if(current_mode == 4) {
      // PR_B: B xanh, A d?, 2 b?ng = 99
      all_off();
      output_bit(LED_B_GREEN,1);
      output_bit(LED_A_RED,  1);
      remA = 99;
      remB = 99;
      show_AB_count(remA, remB);
   }
}

// ================= ADVANCE PHA DAY =================
void advance_phase_day() {
   int8 g = get_green_time();
   int8 l = get_left_time();

   phase_id++;
   if(phase_id > 5) phase_id = 0;

   switch(phase_id) {
      case 0: phase_remaining_sec = g; break;   // A xanh
      case 1: phase_remaining_sec = 3; break;   // A v�ng
      case 2: phase_remaining_sec = l; break;   // A tr�i
      case 3: phase_remaining_sec = g; break;   // B xanh
      case 4: phase_remaining_sec = 3; break;   // B v�ng
      case 5: phase_remaining_sec = l; break;   // B tr�i
   }

   compute_counts_from_phase();
   set_leds_for_phase();
   show_AB_count(remA, remB);
}

// M?i 1s tick cho DAY
void one_second_tick_day() {
   if(phase_remaining_sec > 0) {
      phase_remaining_sec--;
      compute_counts_from_phase();
      show_AB_count(remA, remB);
   }

   if(phase_remaining_sec == 0) {
      advance_phase_day();
   }
}

// ================= UPDATE LOGIC 10ms =================
void update_logic_10ms() {
   if(current_mode == 1) {
      // DAY
      ms_accum += 10;
      if(ms_accum >= 1000) {
         ms_accum -= 1000;
         one_second_tick_day();
      }
   }
   else if(current_mode == 2) {
      // NIGHT: 2 d�n v�ng ch?p, 7seg = 00
      blink_ms += 10;
      if(blink_ms >= 500) {
         blink_ms = 0;
         blink_on = !blink_on;
         all_off();
         if(blink_on) {
            output_bit(LED_A_YELLOW,1);
            output_bit(LED_B_YELLOW,1);
         }
         remA = remB = 0;
         show_AB_count(remA, remB);
      }
   }
   else if(current_mode == 3) {
      // PR_A: A xanh, B d?, 2 b?ng = 99 (gi? nguy�n)
      all_off();
      output_bit(LED_A_GREEN,1);
      output_bit(LED_B_RED,  1);
      remA = remB = 99;
      show_AB_count(remA, remB);
   }
   else if(current_mode == 4) {
      // PR_B: B xanh, A d?, 2 b?ng = 99 (gi? nguy�n)
      all_off();
      output_bit(LED_B_GREEN,1);
      output_bit(LED_A_RED,  1);
      remA = remB = 99;
      show_AB_count(remA, remB);
   }
}

// ================= MAIN =================
void main() {
   // PORTD: LED giao th�ng
   set_tris_d(0x00);
   all_off();

   // PORTC: C0..2 output (74HC595), c�c bit kh�c gi? m?c d?nh
   set_tris_c(0b00000000);

   // T?t analog
   setup_adc_ports(NO_ANALOGS);

   current_mode = 1;  // m?c d?nh DAY
   last_mode    = 0;
   uart_phase   = 0;
   current_src  = 0;

   init_mode_state();

   while(TRUE) {
      handle_uart();        // nh?n mode+src t? ESP32 (2 byte)

      if(current_mode != last_mode) {
         init_mode_state();  // d?i mode NGAY
         last_mode = current_mode;
      }

      update_logic_10ms();  // x? l� d�n + 7seg theo current_mode
      delay_ms(10);         // tick 10ms
   }
}

